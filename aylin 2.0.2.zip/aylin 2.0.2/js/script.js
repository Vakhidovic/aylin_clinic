const burger = document.querySelector(".header__burger");
const menu = document.querySelector(".header__menu");

burger.addEventListener("click",
	function () {
		burger.classList.toggle("active");
		menu.classList.toggle("active")
	});



let sliderIndex = 1;
let timeout;
const layers = [...document.querySelectorAll('.layer')];
const covers = [...document.querySelectorAll('.photo-frame')];

function changeCoverAnimState(state = 0) {
	const st = state === 1 ? 'running' : 'paused';
	covers.forEach(cover => {
		// cover.style['animation-play-state'] = st;
		cover.querySelector('.cover').style.width = `${state * 100}%`;
	});
}

function switchLayer(step = 1) {
	const nextSlide = (sliderIndex + step) % 5 === 0 ? 5 : (sliderIndex + step) % 5;

	changeCoverAnimState(1);
	clearTimeout(timeout);
	timeout = setTimeout(() => {
		changeCoverAnimState(0)
	}, 500);

	for(let i of layers) {
		i.classList.remove('layer-displayed');
		i.classList.remove('layer-displayed-exit');
		if(i.dataset.scene == nextSlide) {
			i.classList.add('layer-displayed');
		}
		if(i.dataset.scene == sliderIndex) {
			i.classList.add('layer-displayed-exit');
		}
	}
	sliderIndex = nextSlide;
}
